from test import test_UI


def main():
    test_UI()

if __name__ == "__main__":
    main()